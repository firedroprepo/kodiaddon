# -*- coding: utf-8 -*-

import sys
import os
import urllib
import urllib2
import json
import cookielib
import logging

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, addDirectoryItems, endOfDirectory

from resources.lib.utils import log, log_debug, log_error, parse_argv
#addon = xbmcaddon.Addon()

class SaveItem:
    def __init__(self, url, name):
        url = url
        filename = name
        dialog = xbmcgui.Dialog()
        save_path = dialog.browse(3, "Select the folder to download", 'files').decode("utf-8")
        saveFullPath = os.path.join(save_path, filename)
        basePath = saveFullPath
        ct=1
        while os.path.exists(saveFullPath):
            base = os.path.splitext(basePath)[0]
            fileext = os.path.splitext(basePath)[1]
            saveFullPath = base + '_%s%s' % (ct,fileext)
            ct+=1
            if ct > 99: break
        self.pd = xbmcgui.DialogProgress()
        self.pd.create("Saving","Saving...")
        try:
            fail = False
            if save_path:
                try:
                    urllib.urlretrieve(url,saveFullPath,self.progressUpdate)
                except:
                    fail = True
            else:
                fail = True
            if fail:
                xbmcgui.Dialog().ok("Invalid Path","Please set save path ")
                save_path = dialog.browse(3, "Select the folder to download", 'files').decode("utf-8")
                try:
                    urllib.urlretrieve(url, saveFullPath, self.progressUpdate)
                except:
                    import traceback
                    traceback.print_exc()
                    xbmcgui.Dialog().ok("Fail","Failed to save file.")
                    return
        finally:
            self.pd.close()
        xbmcgui.Dialog().ok("Saved","In: @REPLACE@".replace('@REPLACE@',os.path.basename(saveFullPath)), "In: @REPLACE@".replace('@REPLACE@',save_path))

    def progressUpdate(self,blocks,bsize,fsize):
        #print 'cool',blocks,bsize,fsize
        if fsize == -1 or fsize <= bsize:
            self.pd.update(0)
            #print 'test'
            return
        percent = int((float(blocks) / (fsize/bsize)) * 100)
        #print percent
        self.pd.update(percent)

def download(url, name):
    path = urllib.unquote(url)
    SaveItem(path, name)

if __name__ == '__main__':
    function = sys.argv[1]
    element_url = sys.argv[2]
    element_name = sys.argv[3]


    if function == "download":
        download(element_url, element_name)
    else:
        pass