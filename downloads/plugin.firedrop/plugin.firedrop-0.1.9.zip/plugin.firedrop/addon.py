# -*- coding: utf-8 -*-

import sys
import os
import urllib
import urllib2
import json
import cookielib
import logging

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem, addDirectoryItems, endOfDirectory

import resources.lib.routing as routing
from resources.lib.utils import log, log_debug, log_error, parse_argv


plugin = routing.Plugin()
addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')

dialog = xbmcgui.Dialog()
progress_dialog = xbmcgui.DialogProgress()
progress_dialog_bg = xbmcgui.DialogProgressBG()



STORE = 'file_cookie.txt'
HTTP_HEADER_POST = {"User-Agent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.46 Safari/535.11",
                   "X-Requested-With":"XMLHttpRequest",
                   "Content-type": "application/x-www-form-urlencoded",
                   "Referer": "https://firedrop.com/"}
HTTP_HEADER_GET = {"User-Agent" : "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.11 (KHTML, like Gecko) Chrome/17.0.963.46 Safari/535.11",
                    "Referer": "https://firedrop.com/"}

URL_LOGIN = 'https://firedrop.com/api/kodi.php?mode=login'
URL_MAIN = 'https://firedrop.com/api/kodi.php?mode=dir'
URL_FOLDER = 'https://firedrop.com/api/kodi.php?mode=dir&folder='

IMAGE = ("jpg", "jpeg", "gif", "png", "tiff", "tif", "ico", "pcx", "tga")
VIDEO = ("mp4", "avi","3gp","flv","mkv")
AUDIO = ("mp3", "flac", "ape", "wav", "wave")

addon_path = addon.getAddonInfo('path').decode('utf-8')
thumbpath = os.path.join(addon_path, 'resources', 'thumbnails')
fanart = os.path.join(addon_path, 'fanart.jpg')
sys.path.append(os.path.join(addon_path, 'resources', 'lib'))


def joincookie(vals):
    outstr =""
    for key in vals:
        outstr+= "%s=%s" %(key,vals[key])
    return outstr


def chesk_auth():
    log("Start chesk_auth")
    username = addon.getSetting('username')
    password = addon.getSetting('password')

    if username == "":
        xbmcgui.Dialog().ok(addon.getLocalizedString(12004),addon.getLocalizedString(12005))
        addon.openSettings()
        username = addon.getSetting('username')
        password = addon.getSetting('password')

    try:
        cookie_jar = cookielib.LWPCookieJar()
        try:
            m_session = addon.getSetting('m_session')
        except:
            m_session = ""

        cookie = urllib2.HTTPCookieProcessor(cookie_jar)
        opener = urllib2.build_opener(cookie)
        if m_session != "":
            try:
                opener.addheaders.append(('Cookie', joincookie(json.loads(addon.getSetting('m_session')))))
                return 0, opener
            except:
                pass
        fullurl = URL_LOGIN + "&u=%s&p=%s" %(username, password)
        req = urllib2.Request(fullurl, None, HTTP_HEADER_GET)
        res = opener.open(req)
        body = res.read()
        response = json.loads(body.decode('utf-8'))
        if response['login_status'] == "success":
            aucookie = {}
            for co in cookie_jar:
                aucookie[co.name] = co.value
            addon.setSetting('m_session', json.dumps(aucookie))
            return 0, opener
        else:
            xbmcgui.Dialog().ok(addon.getLocalizedString(12004),addon.getLocalizedString(12007))
            addon.setSetting('m_session', "")
            log_error("Error auth")
            return 1, None
    except Exception as e:
        log_error("Error get url in chesk_auth %s" % e)
        return 2, None


def get_file_type(filename):
    try:
#       fileex = mimetypes.guess_type(filename)
        fileex = filename.split(".")
        fileex = fileex[-1]
        fileex = fileex.lower()
        if fileex in IMAGE:
            type = 'Image'
        elif fileex in VIDEO:
            type = 'video'
        elif fileex in AUDIO:
            type = 'audio'
        else:
            type = None
    except:
        type = None

    return type

def chesk_auth1():
    cookie_jar = cookielib.LWPCookieJar()
    cookie = urllib2.HTTPCookieProcessor(cookie_jar)
    opener = urllib2.build_opener(cookie)
    return 0, opener

def main_parser(url):
    (status, opener) = chesk_auth()
    runAsScript, params = parse_argv()
    listing = []

    if status == 1:
        log_error("Login error")
    elif status == 2:
        log_error("System error")
    else:
        try:
            if url == "":
                murl = URL_MAIN
                dir = ""
            else:
                dir = url.split("/")
                murl = URL_FOLDER + dir[-1]
            req = urllib2.Request(murl, None, HTTP_HEADER_GET)
            res = opener.open(req)
            body = res.read()
            if body.decode('utf-8') == "NEED LOGIN FIRST":
                addon.setSetting('m_session', "")
                (status, opener) = chesk_auth()
                if status == 1:
                    log_error("Login error")
                    return listing
                elif status == 2:
                    log_error("System error")
                    return listing
                else:
                    req = urllib2.Request(murl, None, HTTP_HEADER_GET)
                    res = opener.open(req)
                    body = res.read()

            response = json.loads(body.decode('utf-8'))
            for record in response:
                if record['type'] == "folder":
                    link = url + "/" + record['folderId']
                    if params['content_type'] == "image":
                        item = (plugin.url_for(child_index, urllib.quote_plus(link)) +"?content_type=image", ListItem(record['folderName']), True)
                    elif params['content_type'] == "video":
                        item = (plugin.url_for(child_index, urllib.quote_plus(link)) +"?content_type=video", ListItem(record['folderName']), True)
                    elif params['content_type'] == "audio":
                        item = (plugin.url_for(child_index, urllib.quote_plus(link)) +"?content_type=audio", ListItem(record['folderName']), True)
                    else:
                        item = (plugin.url_for(child_index, urllib.quote_plus(link)), ListItem(record['folderName']), True)
                    listing.append(item)
                elif record['type'] == "file":
                    type = get_file_type(record['fileName'])
                    if type:
                        if params['content_type'] == "image" and type == "Image":
                            title = record['fileName']
                            link = record['imgFull']
                            li =  ListItem(title, iconImage="DefaultImage.png", thumbnailImage=record['imgThumb'])
                            li.setInfo(type="image", infoLabels={"Title": title})
                            li.setProperty('mimetype', 'image/jpeg')
                            li.addContextMenuItems([(addon.getLocalizedString(12001),
                                                     'XBMC.RunScript(special://home/addons/plugin.firedrop/func.py,download,'+urllib.quote_plus(link)+','+title+')')])
                            item = (link, li, False)
                            listing.append(item)
                        elif params['content_type'] == "video" and type == "video":
                            title = record['fileName']
                            link = record['directDownload']
                            try:
                                thumbnailImage = record['videoThumb']
                            except:
                                thumbnailImage = record['imgThumb']

                            li =  ListItem(title, iconImage="DefaultImage.png", thumbnailImage=thumbnailImage)
                            li.setInfo(type="video", infoLabels={"Title": title})
                            li.addContextMenuItems([(addon.getLocalizedString(12001),
                                                     'XBMC.RunScript(special://home/addons/plugin.firedrop/func.py,download,'+urllib.quote_plus(link)+','+title+')')])
                            item = (link, li, False)
                            listing.append(item)
                        elif params['content_type'] == "audio" and type == "audio":
                            title = record['fileName']
                            link = record['directDownload']
                            iconImage = os.path.join(thumbpath, 'audio.jpg')
                            thumbnailImage = os.path.join(thumbpath, 'songs.png')
                            li =  ListItem(title, iconImage=iconImage, thumbnailImage=thumbnailImage)
                            try:
                                titlemusic = record['id3']['title']
                                if isinstance(titlemusic, basestring):
                                    titlemusic = str(titlemusic)
                                elif isinstance(titlemusic, list):
                                    titlemusic = str(titlemusic[0])
                                else:
                                    titlemusic = record['fileName']
                            except:
                                titlemusic = record['fileName']

                            try:
                                artist = record['id3']['artist']
                                if isinstance(artist, basestring):
                                    artist = str(artist)
                                elif isinstance(artist, list):
                                    artist = str(",".join(artist))
                                else:
                                    artist = ""
                            except:
                                artist = ""

                            try:
                                album = record['id3']['album']
                                if isinstance(album, basestring):
                                    album = str(album)
                                elif isinstance(album, list):
                                    album = str(",".join(album))
                                else:
                                    album = ""
                            except:
                                album = ""

                            try:
                                genre = record['id3']['genre']
                                if isinstance(genre, basestring):
                                    genre = str(genre)
                                elif isinstance(genre, list):
                                    genre = str(",".join(genre))
                                else:
                                    genre = ""
                            except:
                                genre = ""

                            try:
                                year = record['id3']['year']
                                if isinstance(year, basestring):
                                    year = str(year)
                                elif isinstance(year, list):
                                    year = str(",".join(year))
                                else:
                                    year = ""
                            except:
                                year = ""

                            try:
                                duration = record['id3']['duration']
                                if isinstance(duration, basestring):
                                    duration = str(duration)
                                elif isinstance(duration, list):
                                    duration = str(",".join(duration))
                                else:
                                    duration = ""
                            except:
                                duration = ""
#                            li.setInfo(type="audio", infoLabels={"Title": title, "Artist": artist})
                            li.setInfo('music', {'title':titlemusic,
                                                'artist':artist,
                                                'album':album,
                                                'genre':genre,
                                                'year':year,
                                                'duration':duration})

                            li.addContextMenuItems([(addon.getLocalizedString(12001),
                                                     'XBMC.RunScript(special://home/addons/plugin.firedrop/func.py,download,'+urllib.quote_plus(link)+','+title+')')])
                            item = (link, li, False)
                            listing.append(item)
        except:
            pass

    return listing

@plugin.route('/')
def index():
    log("START index")
    items = main_parser("")

    addDirectoryItems(plugin.handle, items)
    img = os.path.join(thumbpath, 'settings.png')
    li =  ListItem("Settings", iconImage=img, thumbnailImage=img)
    addDirectoryItem(plugin.handle, plugin.url_for(settings), li, True)
    endOfDirectory(plugin.handle)

@plugin.route('/list/<feed>')
def child_index(feed):
    runAsScript, params = parse_argv()
    path = urllib.unquote(feed)
    items = main_parser(path)
    img = os.path.join(thumbpath, 'previous.png')
    li =  ListItem("  ..  ", iconImage=img, thumbnailImage=img)
    try:
        path = path.split("/")[0:-1]
        if len(path)>1:
            path = "/".join(path)
            addDirectoryItem(plugin.handle, plugin.url_for(child_index, urllib.quote_plus(path))+"?content_type="+params['content_type'], li, True)
        else:
            path = ""
            addDirectoryItem(plugin.handle, plugin.url_for(index) +"?content_type="+params['content_type'], li, True)
    except:
        path = ""
        addDirectoryItem(plugin.handle, plugin.url_for(index)+"?content_type="+params['content_type'], li, True)

    addDirectoryItems(plugin.handle, items)
    endOfDirectory(plugin.handle)

@plugin.route('/category/<category_id>')
def show_category(category_id):
    addDirectoryItem(plugin.handle, "", ListItem("Hello category %s!" % category_id))
    endOfDirectory(plugin.handle)

@plugin.route('/settings')
def settings():
    addon.openSettings()
    addon.setSetting('m_session', "")

@plugin.route('/play/<item>')
def play(item):
    path = urllib.unquote(item)
    print("PLAY ITEM:", path)

if __name__ == '__main__':
    plugin.run()
